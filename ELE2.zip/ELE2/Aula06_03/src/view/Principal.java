package view;

/**
 *
 * @author DaviS.M.dos
 */
public class Principal {

    public static void main(String[] args) {
        new Formulario();
    }
    
}
