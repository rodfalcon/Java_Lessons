
package negocio;

/**
 *
 * @author dreis
 */
abstract class Figura implements IFigura{
    
}
