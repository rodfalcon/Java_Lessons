
package negocio;

/**
 *
 * @author dreis
 */
public interface IFigura {
    float calcularArea();
}
