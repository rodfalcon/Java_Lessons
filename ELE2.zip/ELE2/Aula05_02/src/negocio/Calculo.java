
package negocio;

/**
 *
 * @author dreis
 */
public abstract class Calculo implements ICalculo{

}
