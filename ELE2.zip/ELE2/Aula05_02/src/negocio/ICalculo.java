
package negocio;

/**
 *
 * @author dreis
 */
public interface ICalculo {
    float calcular(float valor1, float valor2);
}
