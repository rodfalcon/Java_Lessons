
package negocio;

/**
 *
 * @author dreis
 */
public class Divisao extends Calculo{

    @Override
    public float calcular(float valor1, float valor2) {
        return valor1 / valor2;
    }
    
}
