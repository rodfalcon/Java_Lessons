
package negocio;

/**
 *
 * @author dreis
 */
public interface ICalculo {
    void somar();
    void subtrair();
    void multiplicar();
    void dividir();
}
