
package view;

import javax.swing.JOptionPane;
import negocio.Carro;
import negocio.Moto;
import negocio.Veiculo;

/**
 *
 * @author dreis
 */
public class Principal {

    public static void main(String[] args) {
        // permite ao usuário selecionar o veículo e seus parâmetros
        int tipoVeiculo = Integer.parseInt(
                JOptionPane.showInputDialog("Qual tipo de veículo deseja " + 
                    "utilizar?\n\n1 - Carro\n2 - Moto"));
        
        // solicita dados do veículo
        String nome = JOptionPane.showInputDialog("Modelo do veículo:");
        String fabricante = JOptionPane.showInputDialog("Fabricante do veículo:");
        int anoFabricacao = Integer.parseInt(JOptionPane.showInputDialog("Ano de fabricação:"));
        
        // declara objeto da classe Veiculo
        Veiculo objVeiculo = null;

        // em função da opção do usuário, instancia objeto específico e atribui a 
        // instância a um objeto da classe pai
        switch(tipoVeiculo){
            case 1:
                int qtdePortas = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de portas:"));
                objVeiculo = new Carro(nome, fabricante, anoFabricacao, qtdePortas);
                break;        
            case 2:
                objVeiculo = new Moto(nome, fabricante, anoFabricacao);
                break;        
        }
        
        // apresenta os dados do veículo
        System.out.println(objVeiculo.informarDados());
        
        // aumenta a velocidade até o limite
        for (int i = 0; i < 25; i++){
            objVeiculo.acelerar();
            System.out.println(String.format("Passo %d: %s", (i+1), objVeiculo.informarDados()));
        }
        
    }
    
}
