
package view;

import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author dreis
 */
public class Formulario {

    private JFrame form;
    private JLabel lblSemLetras;
    private JTextFieldCustom txtSemLetras;

    public Formulario() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        form = new JFrame("Componentes customizados");
        form.setBounds(400, 200, 400, 150);
        form.setLayout(null);
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        lblSemLetras = new JLabel("Não aceita letras:");
        lblSemLetras.setBounds(30, 30, 120, 25);
        form.getContentPane().add(lblSemLetras);

        // *** Caixa de texto que não aceita letras ***
        txtSemLetras = new JTextFieldCustom();
        txtSemLetras.setBounds(160, 30, 160, 25);
        form.getContentPane().add(txtSemLetras);
        
        form.setVisible(true);
    }
}
