
package financeiro;

/**
 *
 * @author dreis
 */
interface IAplicacao {
    void calcularRendimento(float valorAplicado, int prazo, float taxa);    
}
