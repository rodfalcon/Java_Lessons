
package view;

import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author dreis
 */
class Formulario {

    private JFrame form;
    private JLabel lblNomeLabelOriginal;
    private JLabelCustom lblNomeCustomizada;
    
    public Formulario() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        form = new JFrame("Componentes customizados");
        form.setBounds(400, 200, 400, 200);
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        form.setLayout(null);
        
//        lblNomeLabelOriginal = new JLabel("Nome (label original):");
        lblNomeLabelOriginal = new JLabel();
        lblNomeLabelOriginal.setText("Nome (label original):");
        lblNomeLabelOriginal.setBounds(30, 30, 180, 20);
        form.getContentPane().add(lblNomeLabelOriginal);
        
//        lblNomeCustomizada = new JLabelCustom("Nome (label customizada):");
        lblNomeCustomizada = new JLabelCustom();
        lblNomeCustomizada.setText("Nome (label customizada):");
        lblNomeCustomizada.setBounds(30, 70, 180, 20);
        form.getContentPane().add(lblNomeCustomizada);
                
        form.setVisible(true);
    }
    
}
