
package view;

import javax.swing.JLabel;

/**
 *
 * @author dreis
 */
public class JLabelCustom extends JLabel{

    public JLabelCustom(String textoRecebido) {
        super.setText(textoRecebido);
    }

    public JLabelCustom() { }

    @Override
    public void setText(String textoRecebido) {
        super.setText(textoRecebido.toUpperCase()); 
    }
    
}
