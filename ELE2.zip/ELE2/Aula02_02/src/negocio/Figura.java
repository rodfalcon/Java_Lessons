
package negocio;

/**
 *
 * @author dreis
 */
public abstract class Figura {
    
    public abstract float calcularArea();
    
}
