
package view;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author dreis
 */
public class Formulario {

    private JFrame form;
    private JLabel lblGenero, lblInterprete, lblMusica;
    private JComboBox cboGenero, cboInterprete, cboMusica;
    private String[] arrInterpreteRock = {"", "RHCP", "Metallica", "Rolling Stones"},
                     arrInterpreteMPB = {"", "Chico Buarque", "Caetano Veloso", "Zé Ramalho"}, 
                     arrInterpreteTango = {"", "Carlos Gardel", "Astor Piazzolla", "Mercedes Sosa"};
    private String[] arrMusicaRock1 = {"", "Dark Necessities", "Californication", "Give It Away"}, 
                     arrMusicaRock2 = {"", "Enter Sandman", "Nothing Else Matters", "Unforgiven"}, 
                     arrMusicaRock3 = {"", "Satisfaction", "Wild Horses", "Start Me Up"},
                     arrMusicaMPB1 = {"", "Apesar de Você", "Quem Te Viu, Quem Te Vê", "Cotidiano"}, 
                     arrMusicaMPB2 = {"", "Você é Linda", "Sampa", "Você Não Me Ensinou a Te Esquecer"}, 
                     arrMusicaMPB3 = {"", "Chão de Giz", "Avohai", "Admirável Gado Novo"}, 
                     arrMusicaTango1 = {"", "Por Una Cabeza", "El Dia Que Me Quieras", "Volver"},
                     arrMusicaTango2 = {"", "Adios Nonino", "Outono Porteño", "Soledad"},
                     arrMusicaTango3 = {"", "Gracias a La Vida", "Todo Cambia", "Solo le Pido a Dios"};
    
    public Formulario() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        form = new JFrame("JComboBox - música");
        form.setBounds(470, 200, 500, 300);
        form.setLayout(null);
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        lblGenero = new JLabel("Gênero músical:");
        lblGenero.setBounds(30, 30, 100, 20);
        form.getContentPane().add(lblGenero);
        
        cboGenero = new JComboBox();
        cboGenero.setBounds(140, 30, 270, 20);
        cboGenero.addItem("");
        cboGenero.addItem("Rock");
        cboGenero.addItem("MPB");
        cboGenero.addItem("Tango");
        cboGenero.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
            }
        });
        form.getContentPane().add(cboGenero);
                
        lblInterprete = new JLabel("Cantor/Banda:");
        lblInterprete.setBounds(30, 80, 100, 20);
        form.getContentPane().add(lblInterprete);
        
        cboInterprete = new JComboBox();
        cboInterprete.setBounds(140, 80, 270, 20);
        cboInterprete.addItem("");
        cboInterprete.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
            }
        });
        form.getContentPane().add(cboInterprete);
                
        lblMusica = new JLabel("Música:");
        lblMusica.setBounds(30, 130, 100, 20);
        form.getContentPane().add(lblMusica);
        
        cboMusica = new JComboBox();
        cboMusica.setBounds(140, 130, 270, 20);
        cboMusica.addItem("");
        cboMusica.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    JOptionPane.showMessageDialog(null, String.format(
                            "Gênero: %s\nIntérprete: %s\nMúsica: %s", 
                            cboGenero.getSelectedItem().toString(),
                            cboInterprete.getSelectedItem().toString(),
                            cboMusica.getSelectedItem().toString()));
            }
        });
        form.getContentPane().add(cboMusica);
                
        form.setVisible(true);
    }
    
}
