
package negocio;

/**
 *
 * @author dreis
 */
public class Aluno extends Pessoa{

    public Aluno(String nome) {
        super(nome);
    }

}
