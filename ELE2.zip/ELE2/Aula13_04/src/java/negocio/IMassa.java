
package negocio;

/**
 *
 * @author dreis
 */
public interface IMassa {
    float converterQuiloParaLibra(float massa);
    float converterLibraParaQuilo(float massa);
}
