
package view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author dreis
 */
public class Formulario {
    private JFrame form;
    private JLabel lblNome;
    private JTextField txtNome;
    private JButton btnSaudar;

    public Formulario() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        // instancia objeto JFrame
        form = new JFrame("Meu primeiro formulário");
        // define posição (x, y) e tamanho (largura, altura)
        form.setBounds(400, 250, 350, 200);
        // elimina pré-configurações de layout
        form.setLayout(null);
        // configura ação a ser executada ao fechar o formulário
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // recupera objeto da área visual do formulário
        Container painel = form.getContentPane();
        
        // instancia objeto JLabel
        lblNome = new JLabel("Nome:");
        // define posição (x, y) e tamanho (largura, altura)
        lblNome.setBounds(40, 30, 50, 25);
        // configura cor da fonte
        lblNome.setForeground(Color.BLUE);
        // configura tipo de fonte
        Font fonteCustomizada = new Font(lblNome.getFont().getName(),
                                         lblNome.getFont().getStyle(), 14);
        lblNome.setFont(fonteCustomizada);
        // adiciona JLabel à área visual (própria para componentes) do form
        painel.add(lblNome);
        
        // instancia objeto JTextField
        txtNome = new JTextField();
        // define posição (x, y) e tamanho (largura, altura)
        txtNome.setBounds(100, 30, 180, 25);
        txtNome.setFont(fonteCustomizada);
        // adiciona JTextField à área visual (própria para componentes) do form
        painel.add(txtNome);
        
        // instancia objeto JButton
        btnSaudar = new JButton("Enviar saudação!");
        // define posição (x, y) e tamanho (largura, altura)
        btnSaudar.setBounds(75, 80, 200, 25);
        // adiciona tratamento de evento para o clique do 
        // botão, utilizando conceito de objeto anônimo
        btnSaudar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, 
                    String.format("Olá, %s, seja bem-vindo!", txtNome.getText()));
            }
        });
        // adiciona JButton à área visual (própria para componentes) do form
        painel.add(btnSaudar);
        
        // apresenta o formulário
        form.setVisible(true);
    }

    
}
