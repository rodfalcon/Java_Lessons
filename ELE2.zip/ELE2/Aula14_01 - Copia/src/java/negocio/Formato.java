/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;
import servlets.ServletRedirecionador;
/**
 *
 * @author lab1
 */
public class Formato{
   public String retornar_maiusculo(String texto){
        
            return texto.toUpperCase();
        }
    
   public String  retornar_minusculo(String texto){
       return texto.toLowerCase();
   }
}
