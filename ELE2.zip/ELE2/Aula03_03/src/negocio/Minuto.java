
package negocio;

/**
 *
 * @author dreis
 */
class Minuto extends Tempo{
    
}
