
package negocio;

/**
 *
 * @author dreis
 */
class Hora extends Tempo{
    
}
