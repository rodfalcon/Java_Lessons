
package negocio;

/**
 *
 * @author dreis
 */
public interface ICalculo {
    void calcular(); 
}
